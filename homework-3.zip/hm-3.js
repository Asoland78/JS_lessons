class Validation {
    constructor(param) {
        let name, check, message = {}; // доступ по ссылке, чтобы в функцие reduce получить доступ по контесту
        this.name = name;
        this.check = check;
        this.message = message;
        let validate = this.validate;
        let error = this.error;


        this.errors = new Map();

        let p = [];
        this.output = param.reduce(function (total, current) {
            name = current.name;
            check = current.check;
            message = current.name;
            return p.push(validate(current));
        }, 0); // массив объектов разбиваем и по очереди передаем в validate, на выходе получаем массив результатов


    }

    toggleValidator(name, state) {

        if (state === undefined) {
            state = true;
        }

        if (typeof state === "boolean") {
            state = state === false;
        }
        return [name, state];

    }

    validate(value) {

        /* some validations*/

        return {
            valid: 'true',
            errors: this.errors.get(this.name)
        }
    }


}


