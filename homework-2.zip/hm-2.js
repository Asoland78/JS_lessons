(function () {

    function sdf(e){
        console.log('we');
        function createTagsField(e) {
            let countDiv = document.getElementsByClassName("tags").length;
            let textEl = e.target.value;
            let g = {
                getTags: function() {
                   let getAlltags = document.getElementsByClassName("tags");
                    for (let i=0;i<getAlltags.length;i++) {
                       console.log(getAlltags[i].innerHTML);
                    }

                },
                destroy: function(el) {
                    el.removeEventListener('click',sdf);
                   el.remove();

                },
                element:  function () {
                    let node = document.createElement("div");

                    let textnode = document.createTextNode(textEl.replace(',',''));
                    node.appendChild(textnode);
                    node.classList.add("tags");
                    node.dataset.count = countDiv+1;
                    node.addEventListener('click',sdf);
                    e.target.value ='';
                    return node;
                }



            }
            return g;

        }

        let tagField = createTagsField(e);

        if (e.target.getAttribute("data-count")) {
            tagField.destroy(e.target);
        }

        if (e.data === ','){
                document.body.append(tagField.element());
                tagField.getTags();
        }
    }

    document.getElementById('parentDiv').addEventListener('input',sdf, false);

} )();

